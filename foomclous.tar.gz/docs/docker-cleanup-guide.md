# Docker 垃圾清理指南

本文档提供了清理 FoomClous 项目 Docker 垃圾文件的详细指南。

## 📋 目录

- [快速清理](#快速清理)
- [分步清理](#分步清理)
- [清理说明](#清理说明)
- [注意事项](#注意事项)

---

## 🚀 快速清理

### 方法 1：使用清理脚本（推荐）

```bash
# 1. 赋予脚本执行权限
chmod +x docker-cleanup.sh

# 2. 运行清理脚本
./docker-cleanup.sh
```

### 方法 2：一键清理所有未使用资源

```bash
# ⚠️ 警告：这会删除所有未使用的容器、镜像、网络和卷
docker system prune -a --volumes -f
```

---

## 🔧 分步清理

### 1. 停止并删除容器

```bash
# 停止并删除 docker-compose 管理的容器
docker-compose down

# 删除所有停止的容器
docker container prune -f
```

### 2. 清理镜像

```bash
# 查看所有镜像
docker images

# 删除未使用的镜像
docker image prune -a -f

# 删除特定镜像（可选）
docker rmi <镜像ID>
```

### 3. 清理卷

```bash
# 查看所有卷
docker volume ls

# 删除未使用的卷（⚠️ 会删除数据！）
docker volume prune -f

# 删除特定卷（可选）
docker volume rm <卷名>
```

### 4. 清理网络

```bash
# 查看所有网络
docker network ls

# 删除未使用的网络
docker network prune -f
```

### 5. 清理构建缓存

```bash
# 删除所有构建缓存
docker builder prune -a -f
```

---

## 📊 清理说明

### 各类资源说明

| 资源类型 | 说明 | 是否删除数据 |
|---------|------|------------|
| **容器** | 运行中的应用实例 | ❌ 否 |
| **镜像** | 构建的应用镜像 | ❌ 否 |
| **卷** | 持久化数据存储 | ⚠️ **是** |
| **网络** | 容器间通信网络 | ❌ 否 |
| **构建缓存** | Docker 构建时的缓存层 | ❌ 否 |

### 本项目使用的卷

根据 `docker-compose.yml`，本项目使用以下卷：

- **`file-storage`**: 存储上传的文件、缩略图和分块数据
  - `/data/uploads` - 上传的文件
  - `/data/thumbnails` - 缩略图
  - `/data/chunks` - 分块数据

- **`postgres-data`**: PostgreSQL 数据库数据
  - `/var/lib/postgresql/data` - 数据库文件

⚠️ **警告**：删除这些卷会导致所有上传的文件和数据库数据丢失！

---

## ⚠️ 注意事项

### 1. 数据备份

在清理卷之前，请确保已备份重要数据：

```bash
# 备份数据库
docker-compose exec postgres pg_dump -U foomclous foomclous > backup.sql

# 备份文件存储（在宿主机上）
docker run --rm -v foomclous_file-storage:/data -v $(pwd):/backup alpine tar czf /backup/file-storage-backup.tar.gz /data
```

### 2. 保留特定卷

如果只想清理镜像和缓存，而不删除数据卷：

```bash
# 不使用 --volumes 参数
docker system prune -a -f
```

### 3. 查看磁盘使用情况

清理前后可以查看磁盘使用情况：

```bash
# 查看 Docker 磁盘使用
docker system df

# 详细信息
docker system df -v
```

### 4. 重新启动项目

清理后重新启动项目：

```bash
# 重新构建并启动
docker-compose up -d --build

# 或者只启动（如果镜像还在）
docker-compose up -d
```

---

## 🔍 常见问题

### Q1: 清理后项目无法启动？

**A**: 如果删除了镜像，需要重新构建：

```bash
docker-compose up -d --build
```

### Q2: 数据丢失了怎么办？

**A**: 如果误删了卷，只能从备份恢复：

```bash
# 恢复数据库
docker-compose exec -T postgres psql -U foomclous foomclous < backup.sql

# 恢复文件存储
docker run --rm -v foomclous_file-storage:/data -v $(pwd):/backup alpine tar xzf /backup/file-storage-backup.tar.gz -C /
```

### Q3: 如何只清理特定项目的资源？

**A**: 使用 docker-compose 命令：

```bash
# 停止并删除容器、网络（保留卷）
docker-compose down

# 停止并删除容器、网络、卷（⚠️ 删除数据）
docker-compose down -v

# 停止并删除容器、网络、卷、镜像
docker-compose down -v --rmi all
```

### Q4: 磁盘空间不足，如何快速释放？

**A**: 按优先级清理：

```bash
# 1. 先清理构建缓存（通常占用最多）
docker builder prune -a -f

# 2. 清理未使用的镜像
docker image prune -a -f

# 3. 清理停止的容器
docker container prune -f

# 4. 最后考虑清理卷（会删除数据）
docker volume prune -f
```

---

## 📈 监控磁盘使用

定期检查 Docker 磁盘使用情况：

```bash
# 简单查看
docker system df

# 详细查看
docker system df -v

# 查看特定类型
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"
docker volume ls --format "table {{.Name}}\t{{.Driver}}\t{{.Mountpoint}}"
```

---

## 🛡️ 最佳实践

1. **定期清理**：建议每月清理一次构建缓存和未使用的镜像
2. **备份数据**：清理卷之前务必备份数据
3. **监控磁盘**：定期检查 Docker 磁盘使用情况
4. **使用 .dockerignore**：减少构建上下文大小
5. **多阶段构建**：优化镜像大小

---

## 📚 相关命令参考

```bash
# 查看帮助
docker system --help
docker image --help
docker volume --help
docker container --help

# 查看详细信息
docker inspect <容器/镜像/卷>

# 实时监控
docker stats
```
