// Mock data is no longer needed as we use real backend API
// This file is kept for reference only

export const MOCK_FILES: any[] = [];
